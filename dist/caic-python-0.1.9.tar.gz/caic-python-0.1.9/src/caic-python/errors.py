"""caic-python errors."""

class CaicRequestException(Exception):
    """An exception that ocurred during a request to the CAIC website."""
