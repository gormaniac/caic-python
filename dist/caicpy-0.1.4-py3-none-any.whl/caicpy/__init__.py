import logging

logging.basicConfig()
LOGGER = logging.getLogger(__name__)
